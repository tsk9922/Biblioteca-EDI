#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio2.h>
#include <ctype.h>

struct tpPonteiro
{
	int cod;
	tpPonteiro *prox;
};

struct tpLivro
{
	char aut[30];
	char tit[50];
	tpPonteiro *exd;
	tpPonteiro	*exe;
	tpLivro *prox;
};

struct tDescritor
{
	int qtd;
	tpLivro *inicio, *fim;
};

void Inicializar(tDescritor &d)
{
	d.inicio = NULL;
	d.fim = NULL;
	d.qtd = 0;
}

tpPonteiro *NovoEx(int cod)
{
	tpPonteiro *pPont = new tpPonteiro;
	
	pPont->cod = cod;
	pPont->prox = NULL;
	
	return pPont;
}

tpLivro *NovaCaixa(char aut[30], char tit[50])
{
	tpLivro *pLivro = new tpLivro;
	
	strcpy(pLivro->aut,aut);
	strcpy(pLivro->tit,tit);
	pLivro->exd = NULL;
	pLivro->exe = NULL;
	pLivro->prox = NULL;
	
	return pLivro;
}

void *Inserir(tDescritor &desc)
{
	tpLivro *pLivro = new tpLivro;
	tpLivro *auxL;
	tpPonteiro *pPont = new tpPonteiro;
	tpPonteiro *auxP;
	FILE *pLe = fopen("LivrosCSV.txt","r");
	char auxA[30], auxT[50];
	int flagl,flage,auxC;
	
	while(!feof(pLe))
	{
		fscanf(pLe,"%d\n",&flagl);
		
		if(flagl){
			fscanf(pLe, "%[^;];%[^\n]\n", &auxT, &auxA);
			pLivro = NovaCaixa(auxA, auxT);
			
			if(desc.qtd == 0)
			{
				desc.inicio = pLivro;
				desc.fim = pLivro;
			}
			else
			{
				desc.fim->prox = pLivro;
				desc.fim = pLivro;
			}
			desc.qtd++;
		}
		else{
			fscanf(pLe,"%[^;];%d;%d\n",&auxT,&flage,&auxC);
			pPont = NovoEx(auxC);
			auxL = desc.inicio;
			while(auxL!=NULL && stricmp(auxL->tit,auxT)!=0)
				auxL=auxL->prox;
			if(auxL!=NULL){
				if(flage){
					auxP = auxL->exd;
					if(auxP == NULL){
						auxL->exd = pPont;
					}
					else{
						while(auxP->prox!=NULL)
							auxP=auxP->prox;
						auxP->prox = pPont;
					}
				}
				else{
					auxP = auxL->exe;
					if(auxP == NULL){
						auxL->exe = pPont;
					}
					else{
						while(auxP->prox!=NULL)
							auxP=auxP->prox;
						auxP->prox = pPont;
					}
				}
			}
			else{
				printf("\nLivro nao encontrado!");
				getch();
			}	
		}
		
	}
	
	fclose(pLe);
}

void emprestimo(char tit[50],tDescritor d){
	tpLivro *p;
	tpPonteiro *aux;
	
	p = d.inicio;
	while(p!=NULL && stricmp(p->tit,tit)!=0)
		p=p->prox;
	
	if(p!=NULL){
		if(p->exd != NULL){
			if(p->exe != NULL){
				aux = p->exe;
				while(aux->prox != NULL)
					aux = aux->prox;
				aux->prox = p->exd;	
				p->exd = p->exd->prox;
				aux->prox->prox = NULL;	
			}
			else{
				p->exe = p->exd;
				p->exd = p->exd->prox;
				p->exe->prox = NULL;
			}
			printf("\nLivro emprestado");	
		}
		else{
			printf("\nNao ha livros disponiveis!");
		}
	}
	else
		printf("\nLivro nao encontrado!");
	
	getch();
}

void Devolucao(char tit[50], tDescritor desc)
{
	tpLivro *pLivro;
	tpPonteiro *pAux;
	
	pLivro = desc.inicio;
	
	while(pLivro != NULL && stricmp(pLivro->tit, tit) != 0)
		pLivro = pLivro->prox;
	
	if(pLivro != NULL)
	{
		if(pLivro->exe != NULL)
		{
			if(pLivro->exd != NULL){
				pAux = pLivro->exd;
				while(pAux->prox != NULL)
					pAux = pAux->prox;
				pAux->prox = pLivro->exe;
				pLivro->exe = pLivro->exe->prox;
				pAux->prox->prox = NULL;
			}
			else{
				pLivro->exd = pLivro->exe;
				pLivro->exe = pLivro->exe->prox;
				pLivro->exd->prox = NULL;
			}
			
			printf("\nLivro devolvido!"); 
		}
		else
			printf("\nNao ha livros emprestados!");
	}
	else
	{
		printf("\nLivro nao encontrado!");
	}
	getch();
}

char MenuPrincipal()
{
	char R;
	
	clrscr();
	printf("***Menu Principal***\n");
	printf("\n[A]-Consultar");
	printf("\n[B]-Relatorio");
	printf("\n[C]-Devolucao");
	printf("\n[D]-Emprestimo");
	printf("\n[Esc]-Sair");
	R = toupper(getch());
	
	return R;
}

char MenuConsulta()
{
	char R;
	
	clrscr();
	printf("Escolha o tipo de consulta:\n");
	printf("\n[A]-Autor");
	printf("\n[B]-Titulo");
	printf("\n[Esc]-Sair");

	R = toupper(getch());

	return R;
}

void ExibirDisponiveis(tpLivro *pLivro)
{
	tpPonteiro *p;
	
	p = pLivro->exd;
	while(p!=NULL)
	{
		printf("\nN exemplar: %d", p->cod);
		
		p = p->prox;
	}
}

void ExibirEmprestados(tpLivro *pLivro)
{
	tpPonteiro *p;
	
	p = pLivro->exe;
	while(p!=NULL)
	{
		printf("\nN exemplar: %d", p->cod);
		
		p = p->prox;
	}
}

void ConsultaAutor(char aut[30],tDescritor desc)
{
	tpLivro *pLivro = desc.inicio;
	int cont=0;
	
	while(pLivro != NULL){
		if(stricmp(pLivro->aut, aut)==0)
		{
			printf("\n-------------------------------------------------------------------\n");
			printf("Autor: %s - Titulo: %s", pLivro->aut, pLivro->tit);
			
			printf("\n\nDisponiveis: ");
			ExibirDisponiveis(pLivro);
			
			printf("\n\nEmprestados: ");
			ExibirEmprestados(pLivro);
			
			printf("\n-------------------------------------------------------------------\n");
			printf("Aperte uma tecla para continuar!");
			getch();
			cont++;
			clrscr();
		}	
		pLivro = pLivro->prox;
	}
	if(cont == 0){
		printf("\nAutor nao encontrado!");
		getch();
	}
		
}

void ConsultaTitulo(char tit[50],tDescritor desc)
{
	tpLivro *pLivro = desc.inicio;
	
	while(pLivro != NULL && stricmp(pLivro->tit, tit)!=0)
		pLivro = pLivro->prox;
	
	if(pLivro != NULL)
	{
		printf("\n-------------------------------------------------------------------\n");
		printf("Autor: %s - Titulo: %s", pLivro->aut, pLivro->tit);
		
		printf("\n\nDisponiveis: ");
		ExibirDisponiveis(pLivro);
		
		printf("\n\nEmprestados: ");
		ExibirEmprestados(pLivro);
		
		printf("\n-------------------------------------------------------------------\n");
	}
	else
		printf("\nLivro nao encotrado!");
	
	getch();
}

void Exibir(tpLivro *pLivro)
{
	if(pLivro!=NULL)
	{
		clrscr();
		printf("\n-------------------------------------------------------------------\n");
		printf("Autor: %s - Titulo: %s", pLivro->aut, pLivro->tit);
			
		printf("\n\nDisponiveis: ");
		ExibirDisponiveis(pLivro);
		
		printf("\n\nEmprestados: ");
		ExibirEmprestados(pLivro);
		
		printf("\n-------------------------------------------------------------------\n");
		printf("Aperte uma tecla para continuar!");
		getch();
	}
}

void ExibirTudo(tDescritor desc)
{
	tpLivro *pLivro=desc.inicio;
	
	while(pLivro!=NULL)
	{
		Exibir(pLivro);
		
		pLivro = pLivro->prox;
	}
}

int main()
{
	char R, aux[50];
	tDescritor desc;
	
	Inicializar(desc);
	Inserir(desc);
	
	do
	{
		R = MenuPrincipal();
		switch(R)
		{
			case'A':
				do
				{
					R = MenuConsulta();
					switch(R)
					{
						case'A':
							printf("\nDigite o nome do Autor: ");
							fflush(stdin);
							gets(aux);
							ConsultaAutor(aux,desc);
							break;
							
						case'B':
							printf("\nDigite o Titulo: ");
							fflush(stdin);
							gets(aux);
							ConsultaTitulo(aux,desc);
							break;
					}
				}while(R!=27);
				R=0;
				break;
				
			case'B':
				ExibirTudo(desc);
				break;
			case 'C':
				printf("\nDigite o nome do livro:");
				fflush(stdin);
				gets(aux);
				Devolucao(aux,desc);
				break;
			case 'D':
				printf("\nDigite o nome do livro:");
				fflush(stdin);
				gets(aux);
				emprestimo(aux,desc);
				break;
		}
	}while(R!=27);
	
	
	return 0;
}
